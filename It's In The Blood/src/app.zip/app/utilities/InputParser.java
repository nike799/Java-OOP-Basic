package app.utilities;

public class InputParser {
    public String[] parseInput(String inputLine){
        return  inputLine.split("\\s+");
    }
}
